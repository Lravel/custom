<?php 
// if uninstall.php is not called by WordPress, die
if (!defined('WP_UNINSTALL_PLUGIN')) {
    die;
}

global $wpdb, $table_prefix;
	$wp_em = $table_prefix.'emp';
$trunk ="DROP TABLE `$wp_em`";
$wpdb->query($trunk);
?>