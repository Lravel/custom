<div class="slider">
<img src="http://localhost/code/wp-content/uploads/2022/09/digger.jpeg">
</div>