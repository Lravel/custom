<?php
/**
* Plugin Name: My Plugin
* Description: This is my first Plugin
* Version:01.2.5
* Author:Manoj
* Author URI: https:www.google.com
**/
?>
<?php
if(!defined('ABSPATH')){
	header("location:/");
	die('can not acess');
}
function my_plugin_activation(){
	global $wpdb, $table_prefix;
	$wp_em = $table_prefix.'emp';
	$q ="CREATE TABLE IF NOT EXISTS `$wp_em` (`id` INT NOT NULL AUTO_INCREMENT , `name` VARCHAR(50) NOT NULL , `email` VARCHAR(100) NOT NULL , `status` BOOLEAN NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;";
	$wpdb->query($q);
	//$insert="INSERT INTO `$wp_em` (`name`, `email`, `status`) VALUES ('manoj', 'manojmahajan119@gmail.com', 1);";
$data = array(
		'name' =>'code',
		'email' =>'expertcode@gmai.com',
		'status' =>3
);
$wpdb->insert($wp_em, $data);

	//$wpdb->query($insert);
}
register_activation_hook(__FILE__,'my_plugin_activation');


function my_plugin_deactivation(){
	//my plugin deactivation Hook
	global $wpdb, $table_prefix;
	$wp_em = $table_prefix.'emp';
	//$trunk ="DROP TABLE `$wp_em`";
	$trunk ="TRUNCATE `$wp_em`";
	 $wpdb->query($trunk);
}
register_deactivation_hook(__FILE__,'my_plugin_deactivation');


//js 
add_action('wp_enqueue_scripts','ava_test_init');

function ava_test_init() {
    wp_enqueue_script( 'ava-test-js', plugins_url( '/js/custom.js', __FILE__ ));
	 wp_register_style('oss', plugins_url('/css/style.css',__FILE__ ));
}



function my_sc_function(){
	global $wpdb, $table_prefix;
	$wp_em = $table_prefix.'emp';
//$atts = array_change_key_case((array) $atts, CASE_LOWER);	
// $atts = shortcode_atts(array(
	// 'type' => 'img-gallery',
	// ), $atts);
	//ob_start();
	
	// include $atts['type'].'.php';
//

$select = "SELECT * From `$wp_em`";
$data= $wpdb->get_results($select);
//print_r($data);
ob_start();?>
<table>
	<thead>
		<th><td>Name</td>
				<td>Email</td>
				<td>Status</td>
			</th>
	</thead>
	<tbody>
	<tr>
	<?php 
	foreach($data as $rowdata){ ?>
		
				<td><?php echo $rowdata->id;?></td>
				<td><?php echo $rowdata->name;?></td>
				<td><?php echo $rowdata->email ;?></td>
				<td><?php echo $rowdata->status;?></td>
	<?php } ?>
	
	</tr>
	</tbody>
</table>

<?php
$html = ob_get_clean();
return $html;
 }

add_shortcode('my-sc', 'my_sc_function');
?>