<?php
/*
Plugin Name: Brand-manager
Plugin URI: http://offersgod.com/cpa/
Description: CPA
Version: 1.0
Author: CPA
Author URI: http://swarantek.com/
*/?>
<?php

if ( ! defined( 'ABSPATH' ) ) { 
exit; // Exit if accessed directly
}
function load_scripts() {


wp_enqueue_script('jquery1', 'https://code.jquery.com/ui/1.12.1/jquery-ui.js', array(), null, true);
wp_enqueue_script( 'form_validate', 'http://ajax.aspnetcdn.com/ajax/jquery.validate/1.13.1/jquery.validate.js', array(), null, true);
wp_enqueue_script('boostjquery', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js', array(), null, true);
//wp_enqueue_script( 'form-wickedpickermin', plugins_url( '/js/wickedpicker.min.js', __FILE__ ));
//wp_enqueue_script( 'form-wickedpicker', plugins_url( '/js/wickedpicker.js', __FILE__ ));
}
add_action( 'wp_enqueue_scripts', 'load_scripts' );

use Twilio\Rest\Client;
function ja_global_enqueues() {
wp_enqueue_style  ('style', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css',__FILE__);
wp_enqueue_style  ('stylesheet', plugins_url('css/stylesheet.css',__FILE__));
//wp_enqueue_style  ('wickedpicker', plugins_url('css/wickedpicker.css',__FILE__));
//wp_enqueue_style  ('wickedpicker-min', plugins_url('css/wickedpicker.min.css',__FILE__));
}
add_action( 'wp_enqueue_scripts', 'ja_global_enqueues' );
require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
add_action('admin_menu', 'MyPlugInPage_Menu');
function MyPlugInPage_Menu()
{
$mypage = add_submenu_page(
'',
'My Plugin Page',
'My Plugin Page',
'manage_options',
'MyPlugInPage',
'MyPlugInPage_Template'
);
add_action('load-'. $mypage, 'MyPlugInPage_Load' );
}

function MyPlugInPage_Load(){}
function MyPlugInPage_Template(){
global $wpdb;

	$id=$_GET['id'];
      }

function tt_render_list() {
	
	?>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 98%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}

span.page-numbers.btn.btn-pagination.btn-tb-primary {
   margin: 0 2px 0 0;
   padding-bottom: 5px;
   font-size: 13px;
   text-align: center;
   border: 1px solid #ddd;
   box-shadow: inset 0 1px 2px rgba(0,0,0,.07);
   background-color: #fff;
}
ul.page-numbers li {
    display: inline !important;
}
</style>

<div class="col-md-12 wrap">
<h1 class="wp-heading-inline">Brands</h1>
<?php //echo admin_url(); ?>
<a href="<?php echo admin_url(); ?>admin.php?page=tt_list_test" class="page-title-action">Add New</a>
</div><?php 
echo "page",$page_links = paginate_links( array(
                'base'               => add_query_arg( 'tt_list', '%#%' ),
                'format'             => '',
                'prev_text'          => __( '&laquo;', 'aag' ),
                'next_text'          => __( '&raquo;', 'aag' ),
                'total'              => $num_of_pages,
                'current'            => $pagenum,               
                'base'               => add_query_arg( 'tt_list', '%#%' ),
                'format'             => '',
                'prev_next'          => true,
                'prev_text'          => __( '&larr;', 'aag' ),
                'next_text'          => __( '&rarr;', 'aag' ),
                'before_page_number' => '<li><span class="page-numbers btn btn-pagination btn-tb-primary">',
                'after_page_number'  => '</span></li>'
            ) );
			//echo $page_links;
			 if ( $page_links ) {
                ?>
                <br class="clear">
            <nav id="archive-navigation" class="paging-navigation tbWow fadeInUp" role="navigation" style="visibility: visible; animation-name: fadeInUp;">
                <ul class="page-numbers">
                    <?php echo $page_links; ?>
                </ul>
            </nav>
        <?php   }?>
<table id="customers">
<tr>
 <th>Brand</th>
 <th>URL</th>
 <th>Edit</th>
 <th>Delete</th>
 <th>Status</th>
</tr>

  <?php
  global $wpdb;
$pagenum = isset( $_GET['tt_list'] ) ? absint( $_GET['tt_list'] ) : 1;
        $limit = 30;
        $offset = ($pagenum-1) * $limit;
        //echo $offset;
        $total = $wpdb->get_var( "SELECT COUNT(*) FROM wp_brand" );
        $num_of_pages = ceil( $total / $limit );
	$query = "SELECT * FROM wp_brand LIMIT $offset, $limit";
$result=$wpdb->get_results($query);
//print_r($result);
	?>
    <?php foreach ( $result as $print )   {
		 $mid=  $print->id;
		$stat=  $print->status;

		?>
	<tr class="deletew<?php echo $mid; ?>">
    <td><?php echo $print->brand;?></td>
	<td><?php echo $print->mod;?></td>
	<td><button  onclick="location.href='<?php echo site_url();?>/wp-admin/admin.php?page=tt_list_test&id=<?php echo $mid;?>'" class="edit<?php echo $mid; ?>" value="<?php echo $mid;?>">edit</button></td>
	<td ><button  class="delete<?php echo $mid; ?>" value="<?php echo $mid;?>">Delete</button></td>
    <td >
    <?php if($stat == "1"){ ?>
    <button type="submit" name="desct" class="desct" id="desct<?php echo $mid;  ?>" value="<?php echo $mid;?>" />Deactivate </button>
    <?php } ?>
    <?php if($stat == "0"){ ?>
    <button type="submit" name="acti" class="acti" id="acti<?php echo $mid;  ?>" value="<?php echo $mid;?>" />Activate </button>
    <?php } ?>
    
  
<script>
jQuery(document).ready(function($) {
    $("#acti<?php echo $mid;  ?>").click(function(){
       var acti = $('#acti<?php echo $mid;  ?>').val();
        //alert(acti);
      
   
var ajaxurl = "<?php echo plugins_url( 'deactive_update_stause.php' , __FILE__ ); ?>";
$.ajax({
type: "POST",
url: ajaxurl,
data:{acti: acti },
success: function(data){
 $(".rw<?php echo $mid;  ?>").remove(); 
//alert(data);
if (data){
      window.location.reload(); // This is not jQuery but simple plain ol' JS
    }
     
}
}); 
});
});
</script>

<script>
jQuery(document).ready(function($) {
    $("#desct<?php echo $mid;  ?>").click(function(){
       var desct = $('#desct<?php echo $mid;  ?>').val();
        //alert(desct);
      
   
var ajaxurl = "<?php echo plugins_url( 'update_stause.php' , __FILE__ ); ?>";
$.ajax({
type: "POST",
url: ajaxurl,
data:{desct: desct },
success: function(data){
 //$(".rw<?php echo $mid;  ?>").remove(); 
//alert(data);
 if (data){
      window.location.reload(); // This is not jQuery but simple plain ol' JS
    }

}
}); 
});
});
</script>


 </td>

	<script>
jQuery(document).ready(function($) {
    $(".delete<?php echo $mid;  ?>").click(function(){
       var Del = $('.delete<?php echo $mid;  ?>').val();
        //alert(Del);
			
   
var ajaxurl = "<?php echo plugins_url( 'deletebrand.php' , __FILE__ ); ?>";
$.ajax({
type: "POST",
url: ajaxurl,
data:{Del: Del },
success: function(data){
 //$(".rw<?php echo $mid;  ?>").remove();	
//alert(data);
$(".deletew<?php echo $mid; ?>").remove();

}
});	
});
});
</script>

	<?php }?>
	 </tr>
	 </table>

	
<?php
$page_links = paginate_links( array(
                'base'               => add_query_arg( 'tt_list', '%#%' ),
                'format'             => '',
                'prev_text'          => __( '&laquo;', 'aag' ),
                'next_text'          => __( '&raquo;', 'aag' ),
                'total'              => $num_of_pages,
                'current'            => $pagenum,               
                'base'               => add_query_arg( 'tt_list', '%#%' ),
                'format'             => '',
                'prev_next'          => true,
                'prev_text'          => __( '&larr;', 'aag' ),
                'next_text'          => __( '&rarr;', 'aag' ),
                'before_page_number' => '<li><span class="page-numbers btn btn-pagination btn-tb-primary">',
                'after_page_number'  => '</span></li>'
            ) );
			//echo $page_links;
			 if ( $page_links ) {
                ?>
                <br class="clear">
            <nav id="archive-navigation" class="paging-navigation tbWow fadeInUp" role="navigation" style="visibility: visible; animation-name: fadeInUp;">
                <ul class="page-numbers">
                    <?php echo $page_links; ?>
                </ul>
            </nav>
        <?php   }

	}
function tt_sub_list(){ ?>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 98%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}
span.page-numbers.btn.btn-pagination.btn-tb-primary {
   margin: 0 2px 0 0;
   padding-bottom: 5px;
   font-size: 13px;
   text-align: center;
   border: 1px solid #ddd;
   box-shadow: inset 0 1px 2px rgba(0,0,0,.07);
   background-color: #fff;
}
ul.page-numbers li {
    display: inline !important;
}
</style>
<div class="col-md-12 wrap">
<h1 class="wp-heading-inline">Model</h1>
<?php //echo admin_url(); ?>
<a href="<?php echo admin_url(); ?>admin.php?page=tt_sub_list_page" class="page-title-action">Add New</a>
</div>

<table id="customers">
<tr>
 <th>Brand ID</th>
 <th>Model ID</th>
 <th>Model Name</th>
 <th>Model URL</th>
 <th>Edit</th>
 <th>Delete</th>
</tr>

  <?php
  
    global $wpdb;
$pagenum = isset( $_GET['tt_sub_list'] ) ? absint( $_GET['tt_sub_list'] ) : 1;
        $limit = 30;
        $offset = ($pagenum-1) * $limit;
        //echo $offset;
        $total = $wpdb->get_var( "SELECT COUNT(*) FROM wp_modellreihe" );
        $num_of_pages = ceil( $total / $limit );
	$query = "SELECT * FROM wp_modellreihe LIMIT $offset, $limit";
$result=$wpdb->get_results($query);
  	
	?>
	 
    <?php foreach ( $result as $print )   {
		$mid=$print->modell_id;
		?>
	

	<tr class="deletew<?php echo $mid; ?>">
    <td><?php echo $print->rub_id;?></td>
	<td><?php echo $mid=$print->modell_id;?></td>
	<td><?php echo $print->modell;?></td>
	<td><?php echo $print->modell_mod;?></td>
	<td><button  onclick="location.href='<?php echo site_url();?>/wp-admin/admin.php?page=tt_sub_list_page&id=<?php echo $mid;?>'" class="edit<?php echo $mid; ?>" value="<?php echo $mid;?>">edit</button></td>
	<td><button  class="delete<?php echo $mid; ?>" value="<?php echo $mid;?>">Delete</button></td>

    
	<script>
jQuery(document).ready(function($) {
    $(".delete<?php echo $mid;  ?>").click(function(){
       var Del = $('.delete<?php echo $mid;  ?>').val();
        //alert(Del);
			
   
var ajaxurl = "<?php echo plugins_url( 'delete.php' , __FILE__ ); ?>";
$.ajax({
type: "POST",
url: ajaxurl,
data:{Del: Del },
success: function(data){
 //$(".rw<?php echo $mid;  ?>").remove();	
//alert(data);
$(".deletew<?php echo $mid; ?>").remove();
}
});	
});
});


// jQuery(document).ready(function($) {
    // $(".edit<?php echo $mid; ?>").click(function(){
       // var editr = $('.edit<?php echo $mid; ?>').val();
        //alert(editr);
   // var ajaxurl = "<?php echo plugins_url( 'edit.php' , __FILE__ ); ?>";
// $.ajax({
// type: "POST",
// url: ajaxurl,
// data:{editr: editr },
// success: function(data){
 //$(".rw<?php echo $mid;  ?>").remove();	
//alert(data);

// }
// });	
// });
// });

</script>

</tr>
	<?php }?>
	
</table>
	
	<?php
	 $page_links = paginate_links( array(
                'base'               => add_query_arg( 'tt_sub_list', '%#%' ),
                'format'             => '',
                'prev_text'          => __( '&laquo;', 'aag' ),
                'next_text'          => __( '&raquo;', 'aag' ),
                'total'              => $num_of_pages,
                'current'            => $pagenum,               
                'base'               => add_query_arg( 'tt_sub_list', '%#%' ),
                'format'             => '',
                'prev_next'          => true,
                'prev_text'          => __( '&larr;', 'aag' ),
                'next_text'          => __( '&rarr;', 'aag' ),
                'before_page_number' => '<li><span class="page-numbers btn btn-pagination btn-tb-primary">',
                'after_page_number'  => '</span></li>'
            ) );
			//echo $page_links;
			 if ( $page_links ) {
                ?>
                <br class="clear">
            <nav id="archive-navigation" class="paging-navigation tbWow fadeInUp" role="navigation" style="visibility: visible; animation-name: fadeInUp;">
                <ul class="page-numbers">
                    <?php echo $page_links; ?>
                </ul>
            </nav>
        <?php   }
		
		
		
		
  
 
 }
 add_action('admin_menu', 'tt_add_menu_items');

function tt_add_menu_items() {
add_menu_page('Brand manager', 'Brand manager', 'activate_plugins', 'tt_list_test', 'tt_render_list_page');
 add_submenu_page('tt_list_test', 'Add Brand', 'Add Brand', 'manage_options', 'tt_list_test', 'tt_render_list_page' );
 add_submenu_page('tt_list_test', 'Add Model', 'Add Model', 'manage_options','tt_sub_list_page' ,'tt_sub_list_page' );
 add_submenu_page('tt_list_test', 'Vehicle entry', 'Vehicle entry', 'manage_options','tt_schedule_page' ,'tt_schedule_page' );
 
 add_menu_page('Brand list', 'Brand list', 'activate_plugins', 'tt_list', 'tt_render_list');
    add_submenu_page('tt_list', 'All Brand', 'Brand', 'manage_options', 'tt_list', 'tt_render_list' );
    add_submenu_page('tt_list', 'All Model', 'Model', 'manage_options','tt_sub_list' ,'tt_sub_list' );
 add_submenu_page('tt_list', 'All Vehicle', 'Vehicle', 'manage_options','tt_cars_page' ,'tt_cars_page' );
}
// car pages function
function tt_cars_page()

{

	?>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 98%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}
span.page-numbers.btn.btn-pagination.btn-tb-primary {
   margin: 0 2px 0 0;
   padding-bottom: 5px;
   font-size: 13px;
   text-align: center;
   border: 1px solid #ddd;
   box-shadow: inset 0 1px 2px rgba(0,0,0,.07);
   background-color: #fff;
}
ul.page-numbers li {
    display: inline !important;
}
</style>

<div class="col-md-12 wrap">
<h1 class="wp-heading-inline">Vehicle</h1>
<?php //echo admin_url(); ?>
<a href="<?php echo admin_url(); ?>admin.php?page=tt_schedule_page" class="page-title-action">Add New</a>
</div><?php
 $page_links = paginate_links( array(
                'base'               => add_query_arg( 'tt_cars_page', '%#%' ),
                'format'             => '',
                'prev_text'          => __( '&laquo;', 'aag' ),
                'next_text'          => __( '&raquo;', 'aag' ),
                'total'              => $num_of_pages,
                'current'            => $pagenum,               
                'before_page_number' => '<li><span class="page-numbers btn btn-pagination btn-tb-primary">',
                'after_page_number'  => '</span></li>'
            ) );
            if ( $page_links ) {
                ?>
                <br class="clear">
            <nav id="archive-navigation" class="paging-navigation  tbWow fadeInUp" role="navigation" style="visibility: visible; animation-name: fadeInUp;">
                <ul class="page-numbers ">
                  <?php echo $page_links; ?>
                </ul>
            </nav>
			
      <?php   }?>
<table id="customers">

<tr>
 <th>Vehicle Name</th>
 <th>Vehicle URL</th>
  <th>Vehicle Type</th>
  <th>Edit</th>
 <th>Delete</th>
</tr>

  <?php
global $wpdb;
$pagenum = isset( $_GET['tt_cars_page'] ) ? absint( $_GET['tt_cars_page'] ) : 1;
        $limit = 30;
        $offset = ($pagenum-1) * $limit;
        //echo $offset;
        $total = $wpdb->get_var( "SELECT COUNT(*) FROM wp_car" );
        $num_of_pages = ceil( $total / $limit );
	$query = "SELECT * FROM wp_car LIMIT $offset, $limit";
$result=$wpdb->get_results($query);

	?>
      <?php foreach ( $result as $print )   {
		  $mid=$print->id;
		  ?>
	<tr class="rdelete<?php echo $mid;?>">
    <td><?php echo $print->fahrzeugtyp;?></td>
	<td><?php echo $print->car_mod;?></td>
<td><?php //echo $mid=$print->gas;?><?php if($print->gas == "1"){echo "Petrol";}?> <?php if($print->gas == "2"){echo "Diesel";}?> </td>
	<td><button  onclick="location.href='<?php echo site_url();?>/wp-admin/admin.php?page=tt_schedule_page&id=<?php echo $mid;?>'" class="edit<?php echo $mid; ?>" value="<?php echo $mid;?>">edit</button></td>
	<td ><button  class="delete<?php echo $mid; ?>" id="wdel<?php echo $mid;  ?>" value="<?php echo $mid;?>">Delete</button></td>

    
	<script>
jQuery(document).ready(function($) {
    $(".delete<?php echo $mid;  ?>").click(function(){
       var Del = $('.delete<?php echo $mid;  ?>').val();
       // alert(Del);
			
   
var ajaxurl = "<?php echo plugins_url( 'deletecar.php' , __FILE__ ); ?>";
$.ajax({
type: "POST",
url: ajaxurl,
data:{Del: Del },
success: function(data){
  $('.rdelete<?php echo $mid;?>').remove();



}
});	
});
});
</script>
</tr>
	<?php }?>
	</table>
	<?php
      //Link for Pagination

            $page_links = paginate_links( array(
                'base'               => add_query_arg( 'tt_cars_page', '%#%' ),
                'format'             => '',
                'prev_text'          => __( '&laquo;', 'aag' ),
                'next_text'          => __( '&raquo;', 'aag' ),
                'total'              => $num_of_pages,
                'current'            => $pagenum,               
                'before_page_number' => '<li><span class="page-numbers btn btn-pagination btn-tb-primary">',
                'after_page_number'  => '</span></li>'
            ) );
            if ( $page_links ) {
                ?>
                <br class="clear">
            <nav id="archive-navigation" class="paging-navigation  tbWow fadeInUp" role="navigation" style="visibility: visible; animation-name: fadeInUp;">
                <ul class="page-numbers ">
                  <?php echo $page_links; ?>
                </ul>
            </nav>
			
      <?php   }

}

function tt_render_list_page() {
    ?>
 
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<script>
jQuery(document).ready(function($){
$('#brands').change(function(e) {
 $test = $('#mod').val($(this).val().replace(/\s/g,"-"));
$('#mod').html($test);
});
});
</script>
	<?php 
   $mid=$_GET['id'];

 $brand = $_POST['brand'];
      $mode = $_POST['mod'];
      $english = $_POST['rubriktext_english'];
global $wpdb; 
if ( isset( $_POST['update1'] ) ){
 $sql ="UPDATE wp_brand
    SET brand= '".$brand."',
    `mod` = '".$mode."',
  `rubriktext_en` = '".$english."'
WHERE  `id` = '".$mid."'";
$update_brand = $wpdb->query($sql);
if($update_brand)
{
	echo '<div class="col-md-12 hidden-xs"> <div id="message error hidden-xs" class="updated notice notice-success is-dismissible"><p class="text-primary">your data is updated</p></div></div>';  
}
}

	$query = "SELECT * FROM wp_brand where id=$mid";
$result=$wpdb->get_results($query);

//print_r($result);
foreach ($result as $data){
 $brand = $data->brand;
	 $brandurl = $data->mod;
	  $branddes = $data->rubriktext_en;
	}
	
    if($mid)
    {  
?>

<div class="col-md-4">
<h1>Edit Brand</h1>
<form method="post" enctype="multipart/form-data">

                    <div class="form-group">
                        <label for="name"  class="input-desc" style="color:#333"> Brand Name: </label><br>
                       
                        <input type="text" name="brand" class="form-control brand_con" id="brands"  placeholder="Brand Name" value="<?php echo $brand;  ?>">
                    </div>
                    <p><!-- End .from-group --></p>
                       <div class="form-group">
                    <label for="mod" class="input-desc" style="color:#333">Url(Without Space): </label><br>
                        <input type="text" name="mod" class="form-control" id="mod"  placeholder="Url" value="<?php echo $brandurl;  ?>">
                    
                    <p><!-- End .from-group --></p>
                      </div>
                       <div class="form-group">
                    <label for="rubriktext_en" class="input-desc" style="color:#333">Description </label><br>
                        <textarea type="text" name="rubriktext_english" class="form-control" id="rubriktext_en"  placeholder="Description" ><?php echo $branddes;  ?></textarea>
                           <p><!-- End .from-group --></p>
                    </div>
                 

    
    <input type="submit" name="update1" value="update" id ="submited" class="btn btn-custom2 min-width btn-primary"></p>

                </form>
</div>

<?php  }  else {
	?>

<div class="col-md-4">
<h1>Add Brand</h1>
<form method="post" enctype="multipart/form-data">

                    <div class="form-group">
                        <label for="name"  class="input-desc" style="color:#333"> Brand Name: <span class="required-field">*</span></label><br>
                       
                        <input type="text" name="brand" class="form-control brand_con" id="brands" required="required" placeholder="Brand Name">
                    </div>
                    <p><!-- End .from-group --></p>
                       <div class="form-group">
                    <label for="mod" class="input-desc" style="color:#333">Url(Without Space): <span class="required-field">*</span></label><br>
                        <input type="text" name="mod" class="form-control" id="mod" required="required" placeholder="Url">
                    
                    <p><!-- End .from-group --></p>
                      </div>
                       <div class="form-group">
                    <label for="rubriktext_en" class="input-desc" style="color:#333">Description <span class="required-field">*</span></label><br>
                        <textarea type="text" name="rubriktext_english" class="form-control" id="rubriktext_en" required="required" placeholder="Description"></textarea>
                           <p><!-- End .from-group --></p>
                    </div>
                 

    
    <input type="submit" name="submit" value="Submit" id ="submited" class="btn btn-custom2 min-width btn-primary"></p>

                </form>
</div>
<?php  } ?>
                <?php
               $Brand = $_POST['brand'];
               $Mode = $_POST['mod'];
               $English = $_POST['rubriktext_english'];   

                if ( isset( $_POST['submit'] ) ){
          global $wpdb;
       
	   
	   $checkbrand = "SELECT * FROM wp_brand where brand='$Brand'";
	   $checkbrand=$wpdb->get_results($checkbrand);
	   if($checkbrand){
		   echo '<div class="col-md-12 hidden-xs"> <div id="message error hidden-xs" class="updated notice notice-success is-dismissible"><p class="text-primary"> ',$brand ,' Brand is already exists</p></div></div>';  
	   }
	   else{
  $query =  $wpdb->insert('wp_brand', array(
    'brand' => $Brand,  
    'mod' => $Mode, 
    'rubriktext_en' => $English, // ... and so on 
));
  if($query){
	  echo '<div class="col-md-12 hidden-xs"> <div id="message error hidden-xs" class="updated notice notice-success is-dismissible"><p class="text-primary">your data is Submited</p></div></div>';  
  }
}
				}
// Add Brand  close
     ?>


<?php
}
 // Add Mode  
function tt_sub_list_page() {
	?>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script>
jQuery(document).ready(function($){
$('#model_no').change(function(e) {
    $carmodel = $('#model_mode').val($(this).val().replace(/\s/g,"-"));
$('#model_mode').html($carmodel);
});
});
</script>
    <?php
	
  $mid=$_GET['id'];

global $wpdb; 
if ( isset( $_POST['update'] ) ){
		 $model=$_POST['model_mode'];
$model_no=$_POST['model_no'];
	//echo "hello" ;
	$update_model=$wpdb->query($wpdb->prepare("UPDATE wp_modellreihe SET modell='$model_no' , modell_mod='$model' WHERE modell_id=$mid"));
	if($update_model)
	{
		echo '<div class="col-md-12 hidden-xs"> <div id="message error hidden-xs" class="updated notice notice-success is-dismissible"><p class="text-primary">Your data is updated</p></div></div>';  
	}
	

  }
		$query = "SELECT * FROM wp_modellreihe where modell_id=$mid";
$result=$wpdb->get_results($query);

//print_r($result);
foreach ($result as $data){
 $modell_mod = $data->modell_mod;
	 $modell = $data->modell;
	  $brand = $data->rub_id;
	}
	
    if($mid)
    {  
	 

	
	 ?> 
<div class="col-md-4">
<h1>Update Model</h1>
    <form method="post" enctype="multipart/form-data">
    <div class="form-group">
      <label for="sel1">Brand:</label><br>
      
<?php

    global $wpdb;
$query1 = "SELECT * FROM wp_brand where id=$brand";
$result1=$wpdb->get_results($query1);
//print_r($result1);

 foreach ( $result1 as $page1 ){?>

  
   
<?php } ?>
   <input type="text" class="form-control"  value="<?php echo $page1->brand; ?>" >
      </div>
 <div class="form-group">
                    <label for="model_no"  id="" class="model_no" style="color:#333">Model Name: </label><br>
                        <input type="text"  name="model_no" class="form-control" id="model_no"  placeholder="Model Name" value="<?php echo $modell; ?>">
                           <p><!-- End .from-group --></p>
</div>
 <div class="form-group">
                    <label for="model_mode" class="model_mode" style="color:#333">Url(Without Space): </label><br>
                        <input type="text" name="model_mode" class="form-control" id="model_mode"  placeholder="Url" value="<?php echo  $modell_mod ; ?>">
                           <p><!-- End .from-group --></p>
                           <input type="submit" name="update" value="Update" id ="submited" class="btn btn-custom2 min-width btn-primary">
</div> </form>
    </div>

<?php


	} else { ?>


<div class="col-md-4">
<h1>Add Model</h1>
    <form method="post" enctype="multipart/form-data">
    <div class="form-group">
      <label for="sel1"><h3>Select Brand:</h3></label>
      <select class="form-control" id="sel1" name="brandd">
       <option value="">Select Brand</option>
<?php

    global $wpdb;
$result = $wpdb->get_results('SELECT * FROM wp_brand');


 foreach ( $result as $page ){?>

     <option value="<?php echo $brand_id = $page->id; ?>"><?php echo $page->brand; ?></option>
   
<?php } ?>
</select>
      </div>
 <div class="form-group">
                    <label for="model_no"  id="" class="model_no" style="color:#333">Model Name: <span class="required-field">*</span></label><br>
                        <input type="text"  name="model_no" class="form-control" id="model_no" required="required" placeholder="Model Name">
                           <p><!-- End .from-group --></p>
</div>
 <div class="form-group">
                    <label for="model_mode" class="model_mode" style="color:#333">Url(Without Space): <span class="required-field">*</span></label><br>
                        <input type="text" name="model_mode" class="form-control" id="model_mode" required="required" placeholder="Url">
                           <p><!-- End .from-group --></p>
                           <input type="submit" name="submit" value="Submit" id ="submited" class="btn btn-custom2 min-width btn-primary">
</div> </form>
    </div>
<?php
}

?>
 
</div>
<?php 

              $Rub = $_POST['brandd'];  
                $Modell = $_POST['model_no'];  
                $Mode = $_POST['model_mode'];  

                if ( isset( $_POST['submit'] ) ){
          global $wpdb;
       //echo "your data is Submited";
	   
$checkModel = $wpdb->get_results("SELECT * FROM wp_modellreihe where modell='$Modell'");
if($checkModel)
{
	//echo $Modell,"Model is Already Exists";
	 echo '<div class="col-md-12 hidden-xs"> <div id="message error hidden-xs" class="updated notice notice-success is-dismissible"><p class="text-primary"> ',$Modell ,' Brand is already exists</p></div></div>';  
}
else
{
	  $query =  $wpdb->insert('wp_modellreihe', array(
    'rub_id' => $Rub,  
    'modell' => $Modell, 
    'modell_mod' => $Mode, // ... and so on 
));  
if($query)
{
	//echo"your data is Submited"; 
	echo '<div class="col-md-12 hidden-xs"> <div id="message error hidden-xs" class="updated notice notice-success is-dismissible"><p class="text-primary"> ',$Modell ,' your data is Submited</p></div></div>';  
}

}

  
}
// Add Mode  close
?>

<?php 

	}
// Add Car
// Add Car
function tt_schedule_page() {
	?>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script>
$(document).ready(function(){
$("#brandtest").change(function(){
     var data1 = $('#brandtest').val();
         //alert(data);
   
 
var ajaxurl = "<?php echo plugins_url( 'getUsers.php' , __FILE__ ); ?>";
$.ajax({
type: "POST",
url: ajaxurl,
data:{data1: data1 },
success: function(data){
	 $('#birth_month').html(data);
//alert(data);

}
});
 });
});
</script>

<?php
$rub_id	 = $_POST['brandtest'];
$modell_id = $_POST['birth_month'];
$fahrzeugtyp = $_POST['vehicle_type'];
$hubraum = $_POST['Capacity_type'];
$m_kennung = $_POST['m_identifier'];
$kW = $_POST['k_w'];
$Nm = $_POST['N_m'];
$chip1_kW = $_POST['chip1_kW'];
$chip1_Nm = $_POST['chip1_Nm'];
$chip2_kW = $_POST['chip2_kW'];
$chip2_Nm = $_POST['chip2_Nm'];
$chip3_kW = $_POST['chip3_kW'];
$chip3_Nm = $_POST['chip3_Nm'];
$gas = $_POST['gas_v'];
$car_mod = $_POST['car_mod'];
$car_mod_old = $_POST['car_mod_old'];
$show_powerbox = $_POST['show_powerbox'];
$powerbox = $_POST['power_box'];
$pedalbox = $_POST['pedal_box'];
$channels_pro = $_POST['channels_pros'];
$anz_y_stueck_pro = $_POST['anz_y_stueck_pros'];
$channels_ultra = $_POST['channels_ultra_v'];
$anz_y_stueck_ultra = $_POST['anz_y_stueck_ultra_v'];
$channels_nitro = $_POST['channels_nitrov'];
$anz_y_stueck_nitro = $_POST['channels_pros'];
$sensor_type = $_POST['sensor_type_v'];


 if ( isset( $_POST['submit'] ) ){
    global $wpdb;
      
	   
	   $check_car = "SELECT * FROM wp_car where fahrzeugtyp='$fahrzeugtyp' && modell_id='$modell_id' ";
$check_car=$wpdb->get_results($check_car);
if($check_car){
	//echo $fahrzeugtyp, "Vehicle is Already Exists";
	
	echo '<div class="col-md-12 hidden-xs"> <div id="message error hidden-xs" class="updated notice notice-success is-dismissible"><p class="text-primary">',$fahrzeugtyp,'Vehicle is Already Exists</p></div></div>';  
}
else{
	
  $query=  $wpdb->insert('wp_car', array(
    'rub_id' => $rub_id,
    'modell_id' => $modell_id,
    'fahrzeugtyp' => $fahrzeugtyp, 
	'hubraum' => $hubraum, 
	'm_kennung' => $m_kennung, 
	'kW' => $kW, 
	'Nm' => $Nm, 
	'chip1_kW' => $chip1_kW, 
	'chip1_Nm' => $chip1_Nm, 
	'chip2_kW' => $chip2_kW, 
	'chip3_kW' => $chip3_kW, 
	'chip3_Nm' => $chip3_Nm, 
	'gas' => $gas, 
	'car_mod' => $car_mod, 
	'car_mod_old' => $car_mod_old, 
	'show_powerbox' => $show_powerbox, 
	'powerbox' => $powerbox, 
	'pedalbox' => $pedalbox, 
	'channels_pro' => $channels_pro, 
	'anz_y_stueck_pro' => $anz_y_stueck_pro, 
	'channels_ultra' => $channels_ultra, 
	'anz_y_stueck_ultra' => $anz_y_stueck_ultra, 
	'channels_nitro' => $channels_nitro, 
	'anz_y_stueck_nitro' => $anz_y_stueck_nitro, 
	'sensor_type' => $sensor_type, 
	
));
if($query)
{
	 //echo "your data is Submited";
	 echo '<div class="col-md-12 hidden-xs"> <div id="message error hidden-xs" class="updated notice notice-success is-dismissible"><p class="text-primary">your data is Submited</p></div></div>';  
}
}
}
 $mid = $_GET['id'];
//$rub_id  = $_POST['brandtest'];
//$modell_id = $_POST['birth_month'];
$fahrzeugtyp = $_POST['vehicle_type'];
$hubraum = $_POST['Capacity_type'];
$m_kennung = $_POST['m_identifier'];
$kW = $_POST['k_w'];
$Nm = $_POST['N_m'];
$chip1_kW = $_POST['chip1_kW'];
$chip1_Nm = $_POST['chip1_Nm'];
$chip2_kW = $_POST['chip2_kW'];
$chip2_Nm = $_POST['chip2_Nm'];
$chip3_kW = $_POST['chip3_kW'];
$chip3_Nm = $_POST['chip3_Nm'];
$gas = $_POST['gas_v1'];
$car_mod = $_POST['car_mod'];
$car_mod_old = $_POST['car_mod_old'];
$show_powerbox = $_POST['show_powerbox'];
$powerbox = $_POST['power_box'];
$pedalbox = $_POST['pedal_box'];
$channels_pro = $_POST['channels_pros'];
$anz_y_stueck_pro = $_POST['anz_y_stueck_pros'];
$channels_ultra = $_POST['channels_ultra_v'];
$anz_y_stueck_ultra = $_POST['anz_y_stueck_ultra_v'];
$channels_nitro = $_POST['channels_nitrov'];
$anz_y_stueck_nitro = $_POST['channels_pros'];
$sensor_type = $_POST['sensor_type_v'];

global $wpdb; 
if ( isset( $_POST['update5'] ) ){
 $sql ="UPDATE wp_car
    SET fahrzeugtyp= '".$fahrzeugtyp."',
    `hubraum` = '".$hubraum."',
    `m_kennung` = '".$m_kennung."',
    `kW` = '".$kW."',
    `Nm` = '".$Nm."',
    `chip1_kW` = '".$chip1_kW."',
    `chip1_Nm` = '".$chip1_Nm."',
    `chip2_kW` = '".$chip2_kW."',
    `chip2_Nm` = '".$chip2_Nm."',
    `chip3_kW` = '".$chip3_kW."',
    `chip3_Nm` = '".$chip3_Nm."',
    `gas` = '".$gas."',
    `car_mod_old` = '".$car_mod_old."',
    `show_powerbox` = '".$show_powerbox."',
    `powerbox` = '".$powerbox."',
    `channels_pro` = '".$channels_pro."',
    `anz_y_stueck_pro` = '".$anz_y_stueck_pro."',
    `anz_y_stueck_ultra` = '".$anz_y_stueck_ultra."',
    `channels_nitro` = '".$channels_nitro."',
    `anz_y_stueck_nitro` = '".$anz_y_stueck_nitro."',
    `sensor_type` = '".$sensor_type."',
    `m_kennung` = '".$m_kennung."'
WHERE  `id` = '".$mid."'";
$update_vehicle = $wpdb->query($sql);
if($update_vehicle){
	echo '<div class="col-md-12 hidden-xs"> <div id="message error hidden-xs" class="updated notice notice-success is-dismissible"><p class="text-primary">Your record is updated</p></div></div>';  
}
//print_r($tester);
}
?>
<?php global $wpdb;
 $query1 = "SELECT * FROM wp_car where id=$mid";
$result1=$wpdb->get_results($query1);

//print_r($result1);
foreach ($result1 as $data){
  $vehicle = $data->fahrzeugtyp;
	  $hubraum = $data->hubraum;
	   $gas = $data->gas;
	   $m_kennung = $data->m_kennung;
	     $kW = $data->kW;
	   $Nm = $data->Nm;
     $rub_id=$data->rub_id;
	   $chip1_kW = $data->chip1_kW;
	   $chip3_Nm = $data->chip3_Nm;
	   $chip1_Nm = $data->chip1_Nm;
	     $chip2_kW = $data->chip2_kW;
	   $chip2_Nm = $data->chip2_Nm;
	   $chip3_kW = $data->chip3_kW;
	    $car_mod = $data->car_mod;
		$show_powerbox = $data->show_powerbox;
	     $powerbox = $data->powerbox;
	   $pedalbox = $data->pedalbox;
	   $channels_pro = $data->channels_pro;
	    $anz_y_stueck_pro = $data->anz_y_stueck_pro;
		$channels_ultra = $data->channels_ultra;
	     $anz_y_stueck_ultra = $data->anz_y_stueck_ultra;
	   $channels_nitro = $data->channels_nitro;
	   $anz_y_stueck_nitro = $data->anz_y_stueck_nitro;
	    $sensor_type = $data->sensor_type;
	}
	
if($mid){?>

<div class="col-md-4">
<?php

 global $wpdb;
$query5 = "SELECT * FROM wp_brand where id=$rub_id";
$result5=$wpdb->get_results($query5);

foreach ($result5 as $data){
 $brand4 = $data->brand;
   
  }

$querymodelname = "SELECT * FROM wp_modellreihe where modell=$rub_id";
$resultmain=$wpdb->get_results($querymodelname);

//print_r($resultmain);
foreach ($resultmain as $data){
 $modellname = $data->modell;
   
  }

?>

         <h1>Edit Vehicle</h1>
      <form method="post" enctype="multipart/form-data">
          <div class="form-group">
        <label for="brand_id"   class="brand_id" style="color:#333">Brand Name</label><br>
            <input type="text" class="form-control" id="brand_id"value="<?php echo $brand4; ?> ">
          </div>

        
        <div class="form-group">
            <label for="modell_id"   class="modell_id" style="color:#333">Model Name</label><br>
            
			 <input type="text" class="form-control" id="birth_month" name="birth_month" value="<?php echo $modellname; ?>" >



  
             <p><!-- End .from-group --></p>
        </div>
        <div class="form-group">
            <label for="vehicle type"   class="vt" style="color:#333">Vehicle Name</label><br>
            <input type="text"  name="vehicle_type" class="form-control" id="vehicle_type"  placeholder="Vehicle Name" value="<?php echo $vehicle; ?>">
             <p><!-- End .from-group --></p>
        </div>
        <div class="form-group">


<label for="Type" class="radio" style="color:#333">Vehicle Type</label><br>

<label class="radio-inline">
   <input type="radio" name="gas_v1" id="Radios1" value="1"<?php if($gas == "1"){ ?> checked="checked" <?php } ?>>
   Petrol
 </label>


  <label class="radio-inline">
   <input type="radio" name="gas_v1" id="Radios2" value="2" <?php if($gas == "2"){ ?> checked="checked" <?php } ?>>
   Diesel
 </label>

 </div>
        <div class="form-group">
            <label for="Capacity"   class="cp" style="color:#333">Capacity </label><br>
            <input type="text"  name="Capacity_type" class="form-control" id="Capacity_type"  placeholder="Capacity" value="<?php echo $hubraum; ?>">
             <p><!-- End .from-group --></p>
        </div>

        <div class="form-group">
            <label for="m-identifier"   class="m-identifier" style="color:#333">M Identifier </label><br>
            <input type="text"  name="m_identifier" class="form-control" id="m-identifier"  placeholder="M Identifier" value="<?php echo $m_kennung; ?>">
             <p><!-- End .from-group --></p>
        </div>
        <div class="form-group">
            <label for="kw"   class="kw" style="color:#333">kW </label><br>
            <input type="text"  name="k_w" class="form-control" id="K_W"  placeholder="kW"  value="<?php echo $kW; ?>">
             <p><!-- End .from-group --></p>
        </div>
        <div class="form-group">
            <label for="Nm"   class="Nm" style="color:#333">NM </label><br>
            <input type="text"  name="N_m" class="form-control" id="N_M"  placeholder="NM"   value="<?php echo $Nm; ?>">
             <p><!-- End .from-group --></p>
        </div>
        <div class="form-group">
            <label for="chip1_kW"   class="chip1_kW" style="color:#333">Chip1 kW </label><br>
            <input type="text"  name="chip1_kW" class="form-control" id="chip1_kW"  placeholder="Chip1 kW"   value="<?php echo $chip1_kW; ?>">
             <p><!-- End .from-group --></p>
        </div>
        <div class="form-group">
            <label for="chip1_Nm"   class="chip1_Nm" style="color:#333">Chip1 Nm </label><br>
            <input type="text"  name="chip1_Nm" class="form-control" id="chip1_Nm"  placeholder="Chip1 NM"   value="<?php echo $chip1_Nm; ?>">
             <p><!-- End .from-group --></p>
        </div>

        <div class="form-group">
            <label for="chip2_kW"   class="chip2_kW" style="color:#333">Chip2 kW </label><br>
            <input type="text"  name="chip2_kW" class="form-control" id="chip2_kW"  placeholder="Chip2 kW"   value="<?php echo $chip2_kW; ?>">
             <p><!-- End .from-group --></p>
        </div>
        <div class="form-group">
            <label for="chip2_Nm"   class="chip2_Nm" style="color:#333">Chip2 Nm </label><br>
            <input type="text"  name="chip2_Nm" class="form-control" id="chip2_Nm"  placeholder="Chip2 Nm"   value="<?php echo $chip2_Nm; ?>">
             <p><!-- End .from-group --></p>
        </div>
        <div class="form-group">
            <label for="chip3_kW"   class="chip3_kW" style="color:#333">Chip3 kW </label><br>
            <input type="text"  name="chip3_kW" class="form-control" id="chip3_kW"  placeholder="Chip3 kW" value="<?php echo $chip3_kW; ?>">
             <p><!-- End .from-group --></p>
        </div>
        <div class="form-group">
            <label for="chip3_Nm"   class="chip3_Nm" style="color:#333">Chip3 Nm </label><br>
            <input type="text"  name="chip3_Nm" class="form-control" id="chip3_Nm" placeholder="Chip3 Nm" value="<?php echo $chip3_Nm; ?>">
             <p><!-- End .from-group --></p>
        </div>
 
        
        <div class="form-group">
            <label for="car_mod"   class="car_mod" style="color:#333">Car Mod </label><br>
            <input type="text"  name="car_mod" class="form-control" id="car_mod"  placeholder="Car Mod" value="<?php echo $car_mod; ?>">
             <p><!-- End .from-group --></p>
        </div>

        <div class="form-group">
            <label for="show_powerbox"   class="show_powerbox" style="color:#333">Show Powerbox </label><br>
            <input type="text"  name="show_powerbox" class="form-control" id="show_powerbox"  placeholder="Show Powerbox" value="<?php echo $show_powerbox; ?>">
             <p><!-- End .from-group --></p>
        </div>

        <div class="form-group">
            <label for="powerbox"   class="powerbox" style="color:#333">Powerbox </label><br>
            <input type="text"  name="power_box" class="form-control" id="powerbox"  placeholder="Powerbox"  value="<?php echo $powerbox; ?>">
             <p><!-- End .from-group --></p>
        </div>

        <div class="form-group">
            <label for="pedalbox"   class="pedalbox" style="color:#333">Pedalbox </label><br>
            <input type="text"  name="pedal_box" class="form-control" id="pedal_box"  placeholder="Pedalbox"  value="<?php echo $pedalbox; ?>">
             <p><!-- End .from-group --></p>
        </div>

        <div class="form-group">
            <label for="channels_pro"   class="channels_pro" style="color:#333">Channels Pros </label><br>
            <input type="text"  name="channels_pros" class="form-control" id="channels_pro"  placeholder="Channels Pros"  value="<?php echo $channels_pro; ?>">
             <p><!-- End .from-group --></p>
        </div>

         <div class="form-group">
            <label for="anz_y_stueck_pro"   class="anz_y_stueck_pro" style="color:#333">Anz Y Stueck Pro </label><br>
            <input type="text"  name="anz_y_stueck_pros" class="form-control" id="anz_y_stueck_pro"  placeholder="Anz Y Stueck Pro" value="<?php echo $anz_y_stueck_pro; ?>">
             <p><!-- End .from-group --></p>
        </div>
         <div class="form-group">
            <label for="channels_ultra"   class="channels_ultra" style="color:#333">Channels Ultra </label><br>
            <input type="text"  name="channels_ultra_v" class="form-control" id="channels_ultra"  placeholder="Channels Ultra"  value="<?php echo $channels_ultra; ?>">
             <p><!-- End .from-group --></p>
        </div>

         <div class="form-group">
            <label for="anz_y_stueck_ultra"   class="anz_y_stueck_ultra" style="color:#333">Anz y Stueck Ultra </label><br>
            <input type="text"  name="anz_y_stueck_ultra_v" class="form-control" id="anz_y_stueck_ultra"  placeholder="Anz Y Stueck Ultra"  value="<?php echo $anz_y_stueck_ultra; ?>">
             <p><!-- End .from-group --></p>
        </div>
        <div class="form-group">
            <label for="channels_nitro"   class="channels_nitro" style="color:#333">Channels Nitro </label><br>
            <input type="text"  name="channels_nitrov" class="form-control" id="channels_nitro"  placeholder="Channels Nitro" value="<?php echo $channels_nitro; ?>">
             <p><!-- End .from-group --></p>
        </div>
        <div class="form-group">
            <label for="anz_y_stueck_nitro"   class="anz_y_stueck_nitro" style="color:#333">Anz Y Stueck Nitro </label><br>
            <input type="text"  name="anz_y_stueck_nitro_vt" class="form-control" id="anz_y_stueck_nitro_v"  placeholder="Anz y Stueck Nitro" value="<?php echo $anz_y_stueck_nitro; ?>">
             <p><!-- End .from-group --></p>
        </div>

        <div class="form-group">
            <label for="sensor_type"   class="sensor_type" style="color:#333">Sensor Type </label><br>
            <input type="text"  name="sensor_type_v" class="form-control" id="sensor_type"  placeholder="Sensor Type" value="<?php echo $sensor_type; ?>">
             <p><!-- End .from-group --></p>
        </div>
          <input type="submit" name="update5" value="Submit" id ="submited" class="btn btn-custom2 min-width btn-primary"></p>
      </form> 
</div>
<?php  }
	else
	{
		?>



  <div class="col-md-4">
         <h1>Add Vehicle</h1>
      <form method="post" enctype="multipart/form-data">
          <div class="form-group">
                <select class="form-control" id="brandtest" name="brandtest">
                <option value="">Select Brand</option>
<?php

    global $wpdb;
$result = $wpdb->get_results('SELECT * FROM wp_brand');


 foreach ( $result as $page ){?>

     <option value="<?php echo $brand_id = $page->id; ?>"><?php echo $page->brand; ?></option>
   
<?php } ?>


</select>
        </div>

        
        <div class="form-group">
            <label for="modell_id"   class="modell_id" style="color:#333">Select Model  <span class="required-field">*</span></label><br>
            
			 <select class="form-control" id="birth_month" name="birth_month">

</select>
             <p><!-- End .from-group --></p>
        </div>
        <div class="form-group">
            <label for="vehicle type"   class="vt" style="color:#333">Vehicle Name <span class="required-field">*</span></label><br>
            <input type="text"  name="vehicle_type" class="form-control" id="vehicle_type" required="required" placeholder="Vehicle Name">
             <p><!-- End .from-group --></p>
        </div>
        <div class="form-group">
<label for="Type"   class="radioo" style="color:#333">Vehicle Type <span class="required-field">*</span></label><br>
 <label class="radio-inline">
   <input type="radio" name="gas_v" id="Radios1" value="2">
   Petrol
 </label>
 <label class="radio-inline">
   <input type="radio" name="gas_v" id="Radios2" value="1">
   Diesel
 </label></div>
        <div class="form-group">
            <label for="Capacity"   class="cp" style="color:#333">Capacity <span class="required-field">*</span></label><br>
            <input type="text"  name="Capacity_type" class="form-control" id="Capacity_type" required="required" placeholder="Capacity">
             <p><!-- End .from-group --></p>
        </div>

        <div class="form-group">
            <label for="m-identifier"   class="m-identifier" style="color:#333">M Identifier <span class="required-field">*</span></label><br>
            <input type="text"  name="m_identifier" class="form-control" id="m-identifier" required="required" placeholder="M Identifier">
             <p><!-- End .from-group --></p>
        </div>
        <div class="form-group">
            <label for="kw"   class="kw" style="color:#333">kW <span class="required-field">*</span></label><br>
            <input type="text"  name="k_w" class="form-control" id="K_W" required="required" placeholder="kW">
             <p><!-- End .from-group --></p>
        </div>
        <div class="form-group">
            <label for="Nm"   class="Nm" style="color:#333">NM <span class="required-field">*</span></label><br>
            <input type="text"  name="N_m" class="form-control" id="N_M" required="required" placeholder="NM">
             <p><!-- End .from-group --></p>
        </div>
        <div class="form-group">
            <label for="chip1_kW"   class="chip1_kW" style="color:#333">Chip1 kW <span class="required-field">*</span></label><br>
            <input type="text"  name="chip1_kW" class="form-control" id="chip1_kW" required="required" placeholder="Chip1 kW">
             <p><!-- End .from-group --></p>
        </div>
        <div class="form-group">
            <label for="chip1_Nm"   class="chip1_Nm" style="color:#333">Chip1 Nm <span class="required-field">*</span></label><br>
            <input type="text"  name="chip1_Nm" class="form-control" id="chip1_Nm" required="required" placeholder="Chip1 NM">
             <p><!-- End .from-group --></p>
        </div>

        <div class="form-group">
            <label for="chip2_kW"   class="chip2_kW" style="color:#333">Chip2 kW <span class="required-field">*</span></label><br>
            <input type="text"  name="chip2_kW" class="form-control" id="chip2_kW" required="required" placeholder="Chip2 kW">
             <p><!-- End .from-group --></p>
        </div>
        <div class="form-group">
            <label for="chip2_Nm"   class="chip2_Nm" style="color:#333">Chip2 Nm <span class="required-field">*</span></label><br>
            <input type="text"  name="chip2_Nm" class="form-control" id="chip2_Nm" required="required" placeholder="Chip2 Nm">
             <p><!-- End .from-group --></p>
        </div>
        <div class="form-group">
            <label for="chip3_kW"   class="chip3_kW" style="color:#333">Chip3 kW <span class="required-field">*</span></label><br>
            <input type="text"  name="chip3_kW" class="form-control" id="chip3_kW" required="required" placeholder="Chip3 kW">
             <p><!-- End .from-group --></p>
        </div>
        <div class="form-group">
            <label for="chip3_Nm"   class="chip3_Nm" style="color:#333">Chip3 Nm <span class="required-field">*</span></label><br>
            <input type="text"  name="chip3_Nm" class="form-control" id="chip3_Nm" required="required" placeholder="Chip3 Nm">
             <p><!-- End .from-group --></p>
        </div>
 
        
        <div class="form-group">
            <label for="car_mod"   class="car_mod" style="color:#333">Car Mod <span class="required-field">*</span></label><br>
            <input type="text"  name="car_mod" class="form-control" id="car_mod" required="required" placeholder="Car Mod">
             <p><!-- End .from-group --></p>
        </div>

        <div class="form-group">
            <label for="show_powerbox"   class="show_powerbox" style="color:#333">Show Powerbox <span class="required-field">*</span></label><br>
            <input type="text"  name="show_powerbox" class="form-control" id="show_powerbox" required="required" placeholder="Show Powerbox">
             <p><!-- End .from-group --></p>
        </div>

        <div class="form-group">
            <label for="powerbox"   class="powerbox" style="color:#333">Powerbox <span class="required-field">*</span></label><br>
            <input type="text"  name="power_box" class="form-control" id="powerbox" required="required" placeholder="Powerbox">
             <p><!-- End .from-group --></p>
        </div>

        <div class="form-group">
            <label for="pedalbox"   class="pedalbox" style="color:#333">Pedalbox <span class="required-field">*</span></label><br>
            <input type="text"  name="pedal_box" class="form-control" id="pedal_box" required="required" placeholder="Pedalbox">
             <p><!-- End .from-group --></p>
        </div>

        <div class="form-group">
            <label for="channels_pro"   class="channels_pro" style="color:#333">Channels Pros <span class="required-field">*</span></label><br>
            <input type="text"  name="channels_pros" class="form-control" id="channels_pro" required="required" placeholder="Channels Pros">
             <p><!-- End .from-group --></p>
        </div>

         <div class="form-group">
            <label for="anz_y_stueck_pro"   class="anz_y_stueck_pro" style="color:#333">Anz Y Stueck Pro <span class="required-field">*</span></label><br>
            <input type="text"  name="anz_y_stueck_pros" class="form-control" id="anz_y_stueck_pro" required="required" placeholder="Anz Y Stueck Pro">
             <p><!-- End .from-group --></p>
        </div>
         <div class="form-group">
            <label for="channels_ultra"   class="channels_ultra" style="color:#333">Channels Ultra <span class="required-field">*</span></label><br>
            <input type="text"  name="channels_ultra_v" class="form-control" id="channels_ultra" required="required" placeholder="Channels Ultra">
             <p><!-- End .from-group --></p>
        </div>

         <div class="form-group">
            <label for="anz_y_stueck_ultra"   class="anz_y_stueck_ultra" style="color:#333">Anz y Stueck Ultra <span class="required-field">*</span></label><br>
            <input type="text"  name="anz_y_stueck_ultra_v" class="form-control" id="anz_y_stueck_ultra" required="required" placeholder="Anz Y Stueck Ultra">
             <p><!-- End .from-group --></p>
        </div>
        <div class="form-group">
            <label for="channels_nitro"   class="channels_nitro" style="color:#333">Channels Nitro <span class="required-field">*</span></label><br>
            <input type="text"  name="channels_nitrov" class="form-control" id="channels_nitro" required="required" placeholder="Channels Nitro">
             <p><!-- End .from-group --></p>
        </div>
        <div class="form-group">
            <label for="anz_y_stueck_nitro"   class="anz_y_stueck_nitro" style="color:#333">Anz Y Stueck Nitro <span class="required-field">*</span></label><br>
            <input type="text"  name="anz_y_stueck_nitro_vt" class="form-control" id="anz_y_stueck_nitro_v" required="required" placeholder="Anz y Stueck Nitro">
             <p><!-- End .from-group --></p>
        </div>

        <div class="form-group">
            <label for="sensor_type"   class="sensor_type" style="color:#333">Sensor Type <span class="required-field">*</span></label><br>
            <input type="text"  name="sensor_type_v" class="form-control" id="sensor_type" required="required" placeholder="Sensor Type">
             <p><!-- End .from-group --></p>
        </div>
          <input type="submit" name="submit" value="Submit" id ="submited" class="btn btn-custom2 min-width btn-primary"></p>
      </form> 
</div>

<?php } ?>


<?php

}


function my_form() { 

} 
add_shortcode('form', 'my_form');


?>


