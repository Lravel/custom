<?php
$servername = "localhost";
$username = "root";
$password = "Admin@123";
$dbname = "cpachipt_esqo1";

$Del=$_POST['Del'];

echo $Del;
//print_r($data);
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
   die("Connection failed: " . mysqli_connect_error());
}

$sql = "DELETE FROM wp_brand WHERE id ='$Del'";

if ($conn->query($sql) === TRUE) {
    echo "Record deleted successfully";
} else {
    echo "Error deleting record: " . $conn->error;
}



mysqli_close($conn);
 
 ?>
 
 
 





