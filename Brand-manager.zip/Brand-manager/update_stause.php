<?php
$servername = "localhost";
$username = "root";
$password = "Admin@123";
$dbname = "cpachipt_esqo1";

$desct=$_POST['desct'];

echo $desct;
//print_r($data);
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
   die("Connection failed: " . mysqli_connect_error());
}

$a="0";
$sql = "UPDATE  wp_brand SET status= '".$a."' WHERE id=$desct";

if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
} else {
    echo "Error updating record: " . $conn->error;
}



mysqli_close($conn);
 
 ?>
 
 
 





