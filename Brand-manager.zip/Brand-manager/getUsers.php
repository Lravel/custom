<?php
$servername = "localhost";
$username = "root";
$password = "Admin@123";
$dbname = "cpachipt_esqo1";
$data=$_POST['data1'];
//print_r($data);
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
   die("Connection failed: " . mysqli_connect_error());
}


$sql ="SELECT modell_id, modell FROM wp_modellreihe WHERE   rub_id = '$data'";
$result = $conn->query($sql);
 foreach($result as $row){ 
 $model = $row['modell'];
 $modelid = $row['modell_id'];
 ?>
 
 <option value="<?php echo $modelid; ?>"><?php echo $model; ?></option>
 
<?php
 }


mysqli_close($conn);

?>