<?php
$servername = "localhost";
$username = "root";
$password = "Admin@123";
$dbname = "cpachipt_esqo1";

$acti=$_POST['acti'];

//echo $acti;
//print_r($data);
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
   die("Connection failed: " . mysqli_connect_error());
}

$b="1";
$sql = "UPDATE  wp_brand SET status= '".$b."' WHERE id=$acti";

if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
} else {
    echo "Error updating record: " . $conn->error;
}



mysqli_close($conn);
 
 ?>
 
 
 





